#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
COSECHA FRACTAL DE PI - MOTOR DE DESTILACIÓN O(1)
Arquitectura: NEUROBIT_DEV_TEAM
Propósito: Transmutar la infinitud lineal de Pi en un patrón geométrico 
           mediante ventana deslizante, reducción teosófica y liberación de memoria.
"""

import os
import time

# ==========================================
# 1. EL GENERADOR SPIGOT (La Fuente Inagotable)
# ==========================================
def pi_digit_generator():
    """
    Genera los dígitos de Pi uno por uno (3, 1, 4, 1, 5...).
    Memoria O(1): No almacena el historial. Solo el estado actual.
    """
    k, a, b, a1, b1 = 2, 4, 1, 12, 4
    while True:
        p, q, k = k * k, 2 * k + 1, k + 1
        a, b, a1, b1 = a1, b1, p * a + q * a1, p * b + q * b1
        d, d1 = a // b, a1 // b1
        while d == d1:
            yield int(d)
            a, a1 = 10 * (a % b), 10 * (a1 % b1)
            d, d1 = a // b, a1 // b1

# ==========================================
# 2. EL FILTRO DE COHERENCIA (Reducción Teosófica)
# ==========================================
def teosophic_reduce(n):
    """Reduce cualquier número a su raíz digital (1-9)."""
    if n == 0:
        return 0 # El sistema SINCERO lo detectará, pero Pi no tiene ceros en su flujo denso.
    while n > 9:
        n = sum(int(digit) for digit in str(n))
    return n

# ==========================================
# 3. EL MOTOR DE COSECHA (El Atanor)
# ==========================================
def cosecha_pi_fractal(max_muestras=5, bits_counter=13):
    max_counter = (2 ** bits_counter) - 1  # 1111111111111 en binario = 8191
    
    pi_stream = pi_digit_generator()
    
    # Inhalación inicial: Llenar la ventana de 3 estados
    # Descartamos el '3' entero para trabajar solo con el flujo decimal
    next(pi_stream) 
    a = next(pi_stream)
    b = next(pi_stream)
    nxt = next(pi_stream)
    
    muestra_actual = 1
    counter = 1
    
    # Crear directorio de cosecha si no existe
    os.makedirs("cosecha_pi", exist_ok=True)
    filename = f"cosecha_pi/Cosecha_PI_muestra_{muestra_actual}.txt"
    
    print(f"🌌 Iniciando Cosecha Fractal de Pi...")
    print(f"📂 Archivo objetivo: {filename}")
    print(f"⏳ Contador binario de {bits_counter} bits (1 a {max_counter})\n")
    
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            while muestra_actual <= max_muestras:
                
                # --- EL LATIDO (Procesamiento de la Ventana) ---
                c = a + b
                raw_sum = c + nxt
                red = teosophic_reduce(raw_sum)
                
                # Formateo del Contador Binario (13 bits)
                bin_counter = f"{counter:013b}"
                
                # Registro en Memoria Inmutable (Append)
                # Formato: [Counter] | Semilla (a,b,nxt) | Fruto (red.X)
                line = f"{bin_counter} | {a},{b},{nxt} | red.{red}\n"
                f.write(line)
                
                # --- LIBERACIÓN DE MEMORIA (La Inhalación) ---
                # 'a' se descarta (muere). 'b' hereda su lugar. 'nxt' hereda 'b'.
                a = b
                b = nxt
                nxt = next(pi_stream) # El sistema respira el siguiente decimal
                
                # --- CONTROL DE CICLOS ---
                if counter >= max_counter:
                    print(f"✅ Muestra {muestra_actual} completada. Cerrando {filename}")
                    f.close()
                    muestra_actual += 1
                    counter = 1
                    
                    if muestra_actual <= max_muestras:
                        filename = f"cosecha_pi/Cosecha_PI_muestra_{muestra_actual}.txt"
                        print(f"📂 Abriendo nuevo ciclo: {filename}")
                        f = open(filename, 'a', encoding='utf-8')
                else:
                    counter += 1
                    
    except KeyboardInterrupt:
        print("\n⚠️ Cosecha interrumpida por el Observador (G7).")
    finally:
        print("\n🕊️ Gran Obra de la Cosecha completada. El patrón está listo para tu observación.")

if __name__ == "__main__":
    cosecha_pi_fractal(max_muestras=5, bits_counter=13)